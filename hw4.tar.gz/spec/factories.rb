Factory.define :movie do |movie|
  movie.title "All Dreams"
  movie.rating "R"
  movie.director "Konchalovsky"
  movie.release_date "1976-03-08"
end